#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>
//#include "idfGenerator.h"
//#include "calendar.h"

void createFile(char *baseFileName, int bm,int bd, int em, int ed,int id, char *dirname)
{
        char newBaseFileName[FILENAME_MAX];
        sprintf(newBaseFileName,"%s.idf", baseFileName);
        FILE *baseFilePtr = fopen(newBaseFileName, "r");
        char partedFileName[ FILENAME_MAX ];
        sprintf(partedFileName, "%s%d.idf", baseFileName, id);
        FILE *partedFilePtr= fopen(partedFileName,"w");
        //FILE *runperiodFilePtr= fopen(strcat(dirname,"/runperiodvars.txt"),"a"); //This file stores the names of run period variables. It is read by collation script
        //FILE *annualFilePtr= fopen("annualvars.txt","a"); //This file stores the names of annual variables. It is read by collation script
        puts(partedFileName);
        char line[1000];
        char temp[100];
        fgets(line, 1000, baseFilePtr);
        while(!strstr(line,"RunPeriod,"))
        {
                fprintf(partedFilePtr,"%s",line);
                fgets(line,1000, baseFilePtr);
        }
        fprintf(partedFilePtr,"%s",line);
        char beginMonthLine[50],beginDayLine[50],endMonthLine[50],endDayLine[50],runPeriodNameLine[50],runPeriodPara[250];
        sprintf(runPeriodNameLine,",  !- Name");
        sprintf(beginMonthLine,"%i,  !- Begin Month",bm);
        sprintf(beginDayLine,"%i, !-Begin Day",bd);
        sprintf(endMonthLine, "%i,  !- End Month",em);
        sprintf(endDayLine,"%i, !- End Day of Month",ed);
        sprintf(runPeriodPara,"%s\r\n  %s\r\n  %s\r\n  %s\r\n  %s\r\n  UseWeatherFile,          !- Day of Week for Start Day\r\n",
                                runPeriodNameLine,beginMonthLine,beginDayLine, endMonthLine,endDayLine);
        fprintf(partedFilePtr,"%s",runPeriodPara);
        int i;
        for(i=0;i<6;i++)
                fgets(line,1000,baseFilePtr);
        while(fgets(line,1000,baseFilePtr))
        {
                if( ( strstr(line, "Output:Meter") || strstr(line, "Output:Variable") )
                        && strstr(line, ",RunPeriod")  && id!=13 )
                {
                        puts("Found run period");
                        strcpy( strstr(line,"RunPeriod") , "monthly;\n"  );
                }

                fprintf(partedFilePtr,"%s",line);

                /*
                if(strstr(line, "!- Reporting Frequency") && strstr(line, "annual;") && id!=13 )
                {
                        puts("Found annual");
                        strcpy(line,"    monthly;                 !- Reporting Frequency\n");   
                        if(id == 1) 
                                fprintf(annualFilePtr, "%s", temp);
                }
                //fprintf(partedFilePtr,"%s",line);
                */

/*                if(strstr(line, "!- Reporting Frequency") && strstr(line, "RunPeriod;")  && id!=13 )
                {
                        puts("Found run period");
                        strcpy(line,"    monthly;                 !- Reporting Frequency\n");
                        if(id == 1) //because runperiod file needs to be created only once
                                fprintf(runperiodFilePtr, "%s", temp);
                }
                fprintf(partedFilePtr,"%s",line);

                if( strstr(line,"!- Variable Name") && id == 1 )
                {
                        strcpy(temp,line);
                }
*/
        }
        fclose(partedFilePtr);
//        fclose(runperiodFilePtr);
        //fclose(annualFilePtr);
  //      return;
}


int main(int argc, char **argv)
{
	int rank, processors, count;
	FILE * counter;
	char command[500];


	// Initialize MPI
	// The following lines are used to initialize the MPI on the participating
	// systems and assign rank to each of the participating process. We also
	// keep a record of total number of processess to distributed work among
	// them accordingly
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&processors);

	// The usage syntax of the program is as follows:
	// Usage: mpiexec -n <N> ./energy <IDF_FILE_NAME> <WEATHER_FILE_NAME>
	// We are assuming here that executable is named energy here
	// <N> = Number of participating MPI Processes
	// <IDF_FILE_NAME> = Absolute or Relative path of file containing energy data
	//       of the building ( It should not have the .idf extension in input )
	// <WEATHER_FILE_NAME> = Name of the weather file of the location where the 
	//       building is situated. We do not need the path here, only the name

	// If not all arguments are given

	
	if (argc != 3 )
	{
		// Check for the rank of the process.
		// We do not want to print the error messages multiple times. 
		// So only Process O will print it.
		if (rank == 0)
		{
			printf("Invalid Syntax\n");
			printf("Usage: mpiexec -n <N> ./energy <IDF_FILE_NAME> <WEATHER_FILE_NAME>\n");
		}

		// MPI_Barrier will make all the processes wait till the first process
		// has written the error message. Only then we will terminated the program
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Finalize();

		// Exit with a non-zero return code, so that we know there is an
		// error
		exit(1);
	}

	if(rank == 0) //update the count of simulations done till now. (count is used later to name the folder for the simulation)
	{
		int countarr[2];
		counter = fopen("counter.txt", "r");
		fscanf(counter, "%d", &count);	
		printf("\n\n%d\n\n", ++count);
		fclose(counter);
		counter = fopen("counter.txt","w");
		fprintf(counter,"%d",count);
		fclose(counter);

		// tranfer IDFs
		


		countarr[0] = count;
	  	MPI_Send(countarr, 2, MPI_INT, 1,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 2,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 3,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 4,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 5,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 6,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 7,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 8,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 9,  123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 10, 123, MPI_COMM_WORLD);
	  	MPI_Send(countarr, 2, MPI_INT, 11, 123, MPI_COMM_WORLD);
	 	//MPI_Send(countarr, 2, MPI_INT, 12, 123, MPI_COMM_WORLD);

	}

	else		// send the count value to nodes with rank!=0
	{
		int countarr[2];
		MPI_Status status;
		MPI_Recv(countarr, 2, MPI_INT, 0, 123, MPI_COMM_WORLD, &status);
		count = countarr[0];
		printf("Received count: %d\n", count );
	}

	MPI_Barrier(MPI_COMM_WORLD);

	// The original IDF will be modified to form a new IDF file at each node. 
	// Each process will then read data from its individual IDF file rather than
	// the original IDF


	printf("\nNumber of processors: %d\n", processors );


	printf ("\n\n############################################################### %d \n\n", rank);


	{
		char dirname[200], dirname1[200], command[500], comTime[30];
		int beginMonth, beginDay, endMonth, endDay;

		sprintf(dirname,"%d_%s__%s",count, argv[1], argv[2]  );	
		sprintf(command, "mkdir %s", dirname);
		system(command);				//Create directory for the run: 4_IDFname_EPWname
/*
		sprintf(command,"(time sh copyToAll.sh %s.idf) 2> %d_%s__%s/timeicp ", argv[1], count, argv[1], argv[2]); 	//rename Output folder
		printf("%s\n",command);
		system(command);
//		return;	
*/
		printf("Initialising EnergyPlus on System Rank: %d\n",rank);	

		strcpy(dirname1,dirname);

		switch(rank)
		{
			case 0:	beginDay 	= 1;
				beginMonth 	= 1;
				endDay 		= 31;
				endMonth 	= 1;
				break;

			case 1:	beginDay 	= 1;
				beginMonth 	= 2;
				endDay 		= 28;
				endMonth 	= 2;
				break;

			case 2:	beginDay 	= 1;
				beginMonth 	= 3;
				endDay 		= 31;
				endMonth 	= 3;
				break;

			case 3:	beginDay 	= 1;
				beginMonth 	= 4;
				endDay 		= 30;
				endMonth 	= 4;
				break;

			case 4:	beginDay 	= 1;
				beginMonth 	= 5;
				endDay 		= 31;
				endMonth 	= 5;
				break;

			case 5:	beginDay 	= 1;
				beginMonth 	= 6;
				endDay 		= 30;
				endMonth 	= 6;
				break;

			case 6:	beginDay 	= 1;
				beginMonth 	= 7;
				endDay 		= 31;
				endMonth 	= 7;
				break;

			case 7:	beginDay 	= 1;
				beginMonth 	= 8;
				endDay 		= 31;
				endMonth 	= 8;
				break;

			case 8:	beginDay 	= 1;
				beginMonth 	= 9;
				endDay 		= 30;
				endMonth 	= 9;
				break;

			case 9: beginDay 	= 1;
				beginMonth 	= 10;
				endDay 		= 31;
				endMonth 	= 10;
				break;

			case 10: beginDay 	= 1;
				beginMonth 	= 11;
				endDay 		= 30;
				endMonth 	= 11;
				break;

			case 11: beginDay 	= 1;
				beginMonth 	= 12;
				endDay 		= 31;
				endMonth 	= 12;
				break;
		}

		createFile(argv[1], beginMonth, beginDay, endMonth, endDay, rank + 1, dirname1); 	//create the IDF file for this segment

		sprintf(command, "mv %s%d.idf %s/", argv[1],rank+1, dirname);
		system(command);				//move the splitted IDF to the new directory

		sprintf(comTime,"2> time%d",rank+1);
		sprintf(command,"cd %s; time /usr/local/EnergyPlus-6-0-0/bin/runenergyplus %s%d %s %s", dirname, argv[1], rank+1, argv[2], comTime);
		printf("%s\n",command);
		system(command);				//run energyplus

		sprintf(command,"mv %s/Output/ %s/Output%d",dirname, dirname, rank+1); 	//rename Output folder
		printf("%s\n",command);
		system(command);
/*
		sprintf(command,"cp ../FullYearSimsESOs/%s.eso %s/", argv[1], dirname); 	//rename Output folder
		printf("%s\n",command);
		system(command);

		sprintf(command,"cd %s; perl modifyrunperiod.pl %s", dirname, argv[1]); 	//rename Output folder
		printf("%s\n",command);
		system(command);
*/
	}





	MPI_Barrier(MPI_COMM_WORLD);
        printf("\nI am done\n");


	if(rank == 0) //Copy ESOs from remote system to local system
	{	

		char dirname[700];
		int i;
		sprintf(dirname,"%d_%s__%s",count, argv[1], argv[2]  );	
		
		for(i = 1;i<=processors;i++)
		{
			char copycmd[1000];

			if(i != 1)
				sprintf(copycmd,"(time cp ~/mpi%d/%s/Output%d/%s%d.eso ~/mpi/%s/) 2> ~/mpi/%s/timeecp%d", i, dirname, i, argv[1], i, dirname, dirname, i );
			else
				sprintf(copycmd,"(time cp ~/mpi/%s/Output%d/%s%d.eso ~/mpi/%s/) 2> ~/mpi/%s/timeecp%d", dirname, i, argv[1], i, dirname, dirname, i);
				
			puts( copycmd );
			system(copycmd);
		}

        sprintf(command,"cp ~/mpi/%s.idf ~/mpi/%s/%s.idf", argv[1], dirname, argv[1]);
        printf("%s\n",command);
        system(command);

        sprintf(command,"egrep -i 'Output:Meter|Output:Variable' ~/mpi/%s/%s.idf | egrep -i 'RunPeriod|Monthly' | sort | uniq | sed 's/*,//' | cut -d',' -f2 | sort | uniq -d > ~/mpi/%s/runperiodvarsdouble.txt", dirname, argv[1], dirname);
        printf("%s\n",command);
        system(command);

        sprintf(command,"egrep -i 'Output:Meter|Output:Variable' ~/mpi/%s/%s.idf | egrep -i 'RunPeriod' | sed 's/*,//' | cut -d',' -f2 | sort > ~/mpi/%s/allrunperiodvars.txt", dirname, argv[1], dirname);
        printf("%s\n",command);
        system(command);

        sprintf(command,"cat ~/mpi/%s/allrunperiodvars.txt ~/mpi/%s/runperiodvarsdouble.txt | sort | uniq -u > ~/mpi/%s/runperiodvars.txt", dirname, dirname, dirname);
        printf("%s\n",command);
        system(command);


        sprintf(command,"cp collate12Segsv2.pl ~/mpi/%s/", dirname);
        printf("%s\n",command);
        system(command);
	
        sprintf(command,"cd %s; time perl collate12Segsv2.pl %s > collate12Segsv2.out 2> timeco.out", dirname, argv[1]);
        printf("%s\n",command);
        system(command);
	

        sprintf(command,"cp modifyrunperiod.pl %s/", dirname);
        printf("%s\n",command);
        system(command);


        sprintf(command,"cp ~/FullYearSimsESOs/%s.eso ~/mpi/%s/", argv[1], dirname);
        printf("%s\n",command);
        system(command);

        sprintf(command,"cd ~/mpi/%s; perl modifyrunperiod.pl %s", dirname, argv[1]);
        printf("%s\n",command);
        system(command);




        sprintf(command,"cp qcv2WithSmallDev.pl %s/", dirname);
        printf("%s\n",command);
        system(command);

        sprintf(command,"cd ~/mpi/%s; perl qcv2WithSmallDev.pl %s 0.1 1 > qcresults.txt", dirname, argv[1]);
        printf("%s\n",command);
        system(command);


        sprintf(command,"cp ../FullYearSimsESOs/time%s %s/", argv[1], dirname);
        printf("%s\n",command);
        system(command);

        sprintf(command,"cp ~/mpi/First16Sims/%s.idftime ~/mpi/%s/idfcopytime.txt", argv[1], dirname);
        printf("%s\n",command);
        system(command);

        sprintf(command,"cp ~/mpi/fullcommand.sh ~/mpi/%s/; cd ~/mpi/%s; sh fullcommand.sh %d", dirname, dirname, count);
        printf("%s\n",command);
        system(command);

        sprintf(command,"cp ~/mpi/%s/report.txt ~/mpi/s0w0Reports/%d_%s.txt", dirname, count, argv[1]);
        printf("%s\n",command);
        system(command);

	}

	MPI_Finalize();
	return 0;
}
