#!/usr/bin/perl5.10.1
use POSIX qw(ceil floor);

# Runperiod variables need to be compared properly
# Annual variables
# For monthly and hourly, also check min and max values

if( $#ARGV + 1 < 3 )
{
        print "You must mention the deviation percentage and IDF file name\n";
        print "Usage: ./qc.pl <IDF name> <deviation%> <0/1>\n\n"; # Last digit 0 means average. 1 means peak
        exit;

}

open(INFILE1,"onedayfromsegmented$ARGV[3]_$ARGV[4]_$ARGV[5].eso");

#open(INFILE2,"sorted_final.eso");
open(INFILE2, "onedayfromannual$ARGV[3]_$ARGV[4]_$ARGV[5].eso" );

$designdayscount=`grep "^1," $ARGV[0].eso | wc -l`;
$designdayscount=$designdayscount-2;
print $designdayscount;
#exit;

$linecount = 0;		# Keeps track of line number
$highdevcount = 0;	# Keeps count of more than 10% deviations
$varschecked = 0;	# Number of variables checked
$days = 0;	
$months = 0;	


$totalhourlydatapoints =  `grep '\!Hourly' $ARGV[0].eso | wc -l`;
print "\n$totalhourlydatapoints ";
$totalhourlydatapoints =     $totalhourlydatapoints * 24  ;

$totaldailydatapoints = `grep '\!Daily' $ARGV[0].eso | wc -l`;
print $totaldailydatapoints . " ";
$totaldailydatapoints =      $totaldailydatapoints * (365 + $designdayscount);

$totalmonthlydatapoints = `grep '\!Monthly' $ARGV[0].eso | wc -l`;
print $totalmonthlydatapoints . " ";
$totalmonthlydatapoints =    $totalmonthlydatapoints  * (12 + $designdayscount);

$totalrunperioddatapoints = `grep '\!RunPeriod' $ARGV[0].eso | wc -l`;
print $totalrunperioddatapoints . " ";
$totalrunperioddatapoints =  $totalrunperioddatapoints * ( 1 + $designdayscount );
print "\n$totalhourlydatapoints  $totaldailydatapoints  $totalmonthlydatapoints  $totalrunperioddatapoints";

$maxdev = 0;
$maxid = "";
$maxname = "";

$arr_i = 0; #index for the array storing the report variable IDs

while(<INFILE1>)	# Iterates over the data dictionary
{

	$linecount ++;
	$two = <INFILE2>;

	if(/^[0-9]+,/)
	{
		/^([0-9]+),[0-9]+,(.*)/ ;
                $DDorg[$1]{'name'} = $2;
                $vars[$arr_i] = $1; 		#this array stores the IDs          
                $arr_i = $arr_i + 1;

		
	}
	
	if(/^End of Data Dictionary/)	
	{
		#print "(Data Dictionary ended)\n";
		last;
	}

}

#for($i=0;$i<$arr_i;$i++)
#{
#	print $vars[$i] . " ## " . $DDorg[$vars[$i]]{'name'} . "\n";
#}
#exit;
$point1highdevcount = 0;
$point2highdevcount = 0;
$point3highdevcount = 0;
$point4highdevcount = 0;
$point5highdevcount = 0;

%alldata = ();

while(<INFILE1>)
{
	$linecount ++;
	$two = <INFILE2>;
	if( !( ($_ =~ /^[12345],/) || ($_ =~ /^End of Data/) || ($_ =~ /^ Number of Records Written=/) ) ) 
	#If this line contains data for one of the variables
	{
		#$varschecked ++;
		if( $two ne $_ )    		# If there is any deviation (should be true in most of the cases)
		{	#$two and cmp2 is for collated. $_ and cmp1 is for original

			$varschecked ++;
			/^([0-9]*),([0-9]*(\.[0-9]*)?(E(-)?[0-9]+)?)(,.*)?/;
			$cmp1 = sprintf("%.10f", $2);
			$varname = $DDorg[$1]{'name'};
			$temp_id = $1;
			$rest1 = $2;	# $rest1 and $rest2 contain min max data
			#print "\nabc". $DDorg[$1]{'name'} . "\n" ; 

			if($varname eq "")
			{
				#print $_ . "\n";
				#exit;

			}			


			$two =~ /^[0-9]*,([0-9]*(\.[0-9]*)?(E(-)?[0-9]+)?)(,.*)?/;
			$cmp2 = sprintf("%.10f", $1);
			$rest2 = $2;			

			if($cmp1 != 0)
			{
				$deviation = ($cmp2 - $cmp1)/$cmp1;
			}
			elsif( ($cmp1 == 0) && ($cmp2 != 0) )
			{
				$deviation = 1;
			}
                        elsif( ($cmp1 == 0) && ($cmp2 == 0) )
                        {
                                $deviation = 0;
                        }
			
			if( $deviation > $maxdev )
			{
				if($temp_id != "3823" && $temp_id != "9119" )
				{
					$maxdev = $deviation;
					$maxname = $varname;
					$maxid = $temp_id;
					$maxlinenum = $linecount;
				}

			}
			
			if($rest1 ne $rest2)   
			{
				#print "Min-max mismatch at Line number: $linecount\n". "Variable: $varname\n" .
                                #        "Day: " . ceil(($days / 24) -2) . ", " .
                                #        "Month: " . ($months  -1 ). "\n" .
                                #        "(Original) $_" . 
                                #        "(Collated) $two\n\n" ;

				$minmaxmismatchcount ++;

                                if(! defined $DDorg[$temp_id]{'minmax'} )
                                {
                                        $DDorg[$temp_id]{'minmaxmismatchcount'} = 1;
                                }
                                else    #If the variable has not passed the threshold yet
                                {
                                        $DDorg[$temp_id]{'minmaxmismatchcount'} += 1;
                                }


			}

	                if(! defined $alldata{$varname} )
	                {
	                        $alldata{$varname} = {  
	                                        'vars' => {
								'point5count' => 0, 
								'point4count' => 0, 
								'point3count' => 0,
								'point2count' => 0,
								'point1count' => 0,
								'valuessum' => 0, 
								'valuepeak' => -999999999999999999,
								'zeroscount' => 0,
								'valuesaverage' => 0,
								'index' => 0,
								'ignorecount' => { 	'point5'=> 0, 
											'point4'=> 0, 
											'point3'=> 0, 
											'point2'=> 0,
											'point1'=> 0
										 }
							  } ,             
						 'devinmonthpoint5' => [0,0,0,0,0,0,0,0,0,0,0,0,0], 
			                         'devinmonthpoint4' => [0,0,0,0,0,0,0,0,0,0,0,0,0], 
						 'devinmonthpoint3' => [0,0,0,0,0,0,0,0,0,0,0,0,0], 
						 'devinmonthpoint2' => [0,0,0,0,0,0,0,0,0,0,0,0,0], 
						 'devinmonthpoint1' => [0,0,0,0,0,0,0,0,0,0,0,0,0], 
						 'collatedvalues' => [  ],                           
			                         'originalvalues' => [  ],
						 'collatedlines' => [],
						 'originallines' => [],
						 'linenumbers' => [],
						 'days' => [],
						 'months' => [],
						 'hours' => [],
						 'dev' => [],
						 'ignore' => []
		
				                       };
			}
=start
			if($cmp2 == "0" || $cmp2 == "0.00")
			{	
				$$$alldata{$varname}{'vars'}{'zeroscount'} += 1;
				print $cmp2 . "\n";
			}
			else
			{
				$$$alldata{$varname}{'vars'}{'valuessum'} += $cmp2;
			}
=cut
			if( $cmp2 > $$$alldata{$varname}{'vars'}{'valuepeak'} )
			{
				$$$alldata{$varname}{'vars'}{'valuepeak'} = $cmp2;
			}

			$$$alldata{$varname}{'originalvalues'}[$$$alldata{$varname}{'vars'}{'index'}] = $cmp1;
			$$$alldata{$varname}{'collatedvalues'}[$$$alldata{$varname}{'vars'}{'index'}] = $cmp2 ;
			$$$alldata{$varname}{'originallines'}[$$$alldata{$varname}{'vars'}{'index'}] = $_ ;
			$$$alldata{$varname}{'collatedlines'}[$$$alldata{$varname}{'vars'}{'index'}] = $two;
			$$$alldata{$varname}{'days'}[$$$alldata{$varname}{'vars'}{'index'}] = ceil(($days / 24) -2) ;
			$$$alldata{$varname}{'months'}[$$$alldata{$varname}{'vars'}{'index'}] = $months  -1  ;
			$$$alldata{$varname}{'linenumbers'}[$$$alldata{$varname}{'vars'}{'index'}] =$linecount ;
			$$$alldata{$varname}{'hours'}[$$$alldata{$varname}{'vars'}{'index'}] = $days % 24;


			#print $_ . " Deviation:" . $deviation . "\n";
			if($deviation >= 0.1) #more than 10% deviation
			{
                                #print "Deviation more than 50% at Line number: $linecount\n". "Variable: $varname\n" . 
                                #        "Day: " . ceil(($days / 24) -2) . ", " .
                                #        "Month: " . ($months  -1 ). "\n" .
                                #        "(Original) $_" . 
                                #        "(Collated) $two" .
                                #        "(Original value) $cmp1\n" .
                                #        "(Collated value) $cmp2\n\n"
                                #        ;

                                $point5highdevcount ++;
				$point4highdevcount ++;
				$point3highdevcount ++;
				$point2highdevcount ++;
				$point1highdevcount ++;
				

				$$$alldata{$varname}{'vars'}{'point5count'} ++;
				$$$alldata{$varname}{'vars'}{'point4count'} ++;
				$$$alldata{$varname}{'vars'}{'point3count'} ++;
				$$$alldata{$varname}{'vars'}{'point2count'} ++;
				$$$alldata{$varname}{'vars'}{'point1count'} ++;

				#$$$alldata{$varname}{'devinmonthpoint5'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint4'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint3'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint2'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint1'}[$months-1] ++;


				$$$alldata{$varname}{'dev'}[$$$alldata{$varname}{'vars'}{'index'}] = "50%" ;



			}

			elsif($deviation >= 0.05) #more than 5% deviation
			{

                                $point4highdevcount ++;
                                $point3highdevcount ++;
                                $point2highdevcount ++;
                                $point1highdevcount ++;

                                $$$alldata{$varname}{'vars'}{'point4count'} ++;
                                $$$alldata{$varname}{'vars'}{'point3count'} ++;
                                $$$alldata{$varname}{'vars'}{'point2count'} ++;
                                $$$alldata{$varname}{'vars'}{'point1count'} ++;


				$$$alldata{$varname}{'dev'}[$$$alldata{$varname}{'vars'}{'index'}] = "40%" ;

				#$$$alldata{$varname}{'devinmonthpoint4'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint3'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint2'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint1'}[$months-1] ++;

			}

			elsif($deviation >= 0.03) #more than 3% deviation
			{

                                $point3highdevcount ++;
                                $point2highdevcount ++;
                                $point1highdevcount ++;


                                $$$alldata{$varname}{'vars'}{'point3count'} ++;
                                $$$alldata{$varname}{'vars'}{'point2count'} ++;
                                $$$alldata{$varname}{'vars'}{'point1count'} ++;

				$$$alldata{$varname}{'dev'}[$$$alldata{$varname}{'vars'}{'index'}] = "30%" ;

				#$$$alldata{$varname}{'devinmonthpoint3'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint2'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint1'}[$months-1] ++;

			}

			elsif($deviation >= 0.02) #more than 2% deviation
			{
                                $point2highdevcount ++;
                                $point1highdevcount ++;

                                $$$alldata{$varname}{'vars'}{'point2count'} ++;
                                $$$alldata{$varname}{'vars'}{'point1count'} ++;

				$$$alldata{$varname}{'dev'}[$$$alldata{$varname}{'vars'}{'index'}] = "20%" ;

				#$$$alldata{$varname}{'devinmonthpoint2'}[$months-1] ++;
				#$$$alldata{$varname}{'devinmonthpoint1'}[$months-1] ++;
			}

			elsif($deviation >= 0.01) #more than 1% deviation
			{
                                $point1highdevcount ++;
				$$$alldata{$varname}{'dev'}[$$$alldata{$varname}{'vars'}{'index'}] = "10%" ;
                                $$$alldata{$varname}{'vars'}{'point1count'} ++;
				#$$$alldata{$varname}{'devinmonthpoint1'}[$months-1] ++;
			}

			else
			{
				$$$alldata{$varname}{'dev'}[$$$alldata{$varname}{'vars'}{'index'}] = "less" ;
			}
			
			$$$alldata{$varname}{'vars'}{'index'} ++;
		}
	
	}
	
	else 	#If the current line is a HEADER
	{ 
		#$days stores the hour, $temp stores the day
		if(/^2,/)
		{
			$days++;
		}

		if(/^4,/)
		{
			$months++;
		}
		
		$temp = ceil($days/24);
		$temp -= 2;		# minus because of 2 design days
		if( $temp <= 0 )
		{
			$temp = 1;
		}
		
		if( $two ne $_ )
		{
			#print "Header mismatch at Line: $linecount\n". "Variable: $varname\n" . "(Original) $_" . "(Collated) $two\n" ;
			#print "Correct day: $temp\n";
			
			#<STDIN>;
		}
		$hour = $days % 24;	
 		#$$$alldata{$varname}{'vars'}{'index'} ++;

	}

 	
 	
	
}
#print $linecount;
#print $_ ;
#print $months;


print "\nNumber of records with >50% deviation: " . $point5highdevcount . " out of " . $varschecked;
print "\nNumber of records with >40% deviation: " . $point4highdevcount . " out of " . $varschecked;
print "\nNumber of records with >30% deviation: " . $point3highdevcount . " out of " . $varschecked;
print "\nNumber of records with >20% deviation: " . $point2highdevcount . " out of " . $varschecked;
print "\nNumber of records with >10% deviation: " . $point1highdevcount . " out of " . $varschecked . "\n\n";
print "\nNumber of records with min-max mismatch: " . $minmaxmismatchcount . " out of " . $varschecked . "\n\n";

foreach $varname (keys %alldata)
{
	$varavg = $$$alldata{$varname}{'vars'}{'valuessum'} / (8808 - $$$alldata{$varname}{'vars'}{'zeroscount'}) ;

	for( $i = 0; $i < $$$alldata{$varname}{'vars'}{'index'} ; $i++ )
	{
		if($$$alldata{$varname}{'dev'}[$i] ne "less" )
		{
	        	print "Deviation more than $$$alldata{$varname}{'dev'}[$i] at Line number: $$$alldata{$varname}{'linenumbers'}[$i]"; 
			print   "\nVariable: $varname";

			if( $ARGV[2] == 0  )  #If requested for average
			{
				print "                           $varavg ";
				$comparator = $ARGV[1] * $varavg ;
			}
			elsif( $ARGV[2] == 1 )  #If requested for peak
			{
				print "                            $$$alldata{$varname}{'vars'}{'valuepeak'}";
				$comparator = $ARGV[1] * $$$alldata{$varname}{'vars'}{'valuepeak'};
			}
			else
			{
				print "Invalid third argument. Aborted!";
				exit;
			}
	
			if( $comparator > $$$alldata{$varname}{'collatedvalues'}[$i] )		
			{
				print "IGNORED";
				if($$$alldata{$varname}{'dev'}[$i] eq "50%")
				{
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point5'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point4'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point3'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point2'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point1'} ++;
				}

				elsif($$$alldata{$varname}{'dev'}[$i] eq "40%")
				{
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point4'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point3'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point2'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point1'} ++;
				}

                                elsif($$$alldata{$varname}{'dev'}[$i] eq "30%")
                                {
					#print $$$alldata{$varname}{'vars'}{'ignorecount'}{'point3'};
                                        $$$alldata{$varname}{'vars'}{'ignorecount'}{'point3'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point2'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point1'} ++;

                                }

                                elsif($$$alldata{$varname}{'dev'}[$i] eq "20%")
                                {
                                        $$$alldata{$varname}{'vars'}{'ignorecount'}{'point2'} ++;
					$$$alldata{$varname}{'vars'}{'ignorecount'}{'point1'} ++;
                                }

                                elsif($$$alldata{$varname}{'dev'}[$i] eq "10%")
                                {
                                        $$$alldata{$varname}{'vars'}{'ignorecount'}{'point1'} ++;
                                }

			}
			#	print	" 			IGNORED\n" . 
				print	"\nDay: " . $$$alldata{$varname}{'days'}[$i] . ", " .
					"Month: " . $$$alldata{$varname}{'months'}[$i] . ", " .
					"Hour: " . $$$alldata{$varname}{'hours'}[$i] . "\n" .
					"(Original) $$$alldata{$varname}{'originallines'}[$i]" . 
					"(Collated) $$$alldata{$varname}{'collatedlines'}[$i]" .
					"(Original value) $$$alldata{$varname}{'originalvalues'}[$i]\n" .
					"(Collated value) $$$alldata{$varname}{'collatedvalues'}[$i]\n\n"
					;
		}
	}
}

printf "\n\n%74s%15s%15s%15s%15s%15s", "Variable name", ">10% count", ">5% count", ">3% count", ">2% count", ">1% count\n";
print "--------------------------------------------------------------------------------------------------------------------------------------------\n\n";
$hourlydevcount  = 0;
$monthlydevcount  = 0;
$dailydevcount  = 0;
$runperioddevcount = 0;

$hourlydevcount10  = 0;
$monthlydevcount10  = 0;
$dailydevcount10  = 0;
$runperioddevcount10 = 0;
#$runperioddevcount  = 0;
foreach $varname (keys %alldata)
{
	if(	$$$alldata{$varname}{'vars'}{'point5count'} == "" && $$$alldata{$varname}{'vars'}{'point4count'} == "" &&
		$$$alldata{$varname}{'vars'}{'point3count'} == "" && $$$alldata{$varname}{'vars'}{'point2count'} == "" &&
		$$$alldata{$varname}{'vars'}{'point1count'} == "" 
	  )
	{
		next;
	}
	$varname =~ /([^\!]+)!([a-zA-Z]+)/;
	$varavg = $$$alldata{$varname}{'vars'}{'valuessum'} / 8808 ; 
	
	if($2 eq "Hourly")
	{
		printf "%74s%15s%15s%15s%15s%15s", $1 . "($2)" 
				. "(". $$$alldata{$varname}{'vars'}{'zeroscount'} .")" , 
				$$$alldata{$varname}{'vars'}{'point5count'} . "($$$alldata{$varname}{'vars'}{'ignorecount'}{'point5'})" , 
				$$$alldata{$varname}{'vars'}{'point4count'} . "($$$alldata{$varname}{'vars'}{'ignorecount'}{'point4'})", 
				$$$alldata{$varname}{'vars'}{'point3count'} . "($$$alldata{$varname}{'vars'}{'ignorecount'}{'point3'})",
				$$$alldata{$varname}{'vars'}{'point2count'} . "($$$alldata{$varname}{'vars'}{'ignorecount'}{'point2'})",
				$$$alldata{$varname}{'vars'}{'point1count'} . "($$$alldata{$varname}{'vars'}{'ignorecount'}{'point1'})" . "\n\n";
	}
	else
	{
		printf "%74s%15s%15s%15s%15s%15s", $1 . "($2)" , 
				$$$alldata{$varname}{'vars'}{'point5count'}, 
				$$$alldata{$varname}{'vars'}{'point4count'}, 
				$$$alldata{$varname}{'vars'}{'point3count'},
				$$$alldata{$varname}{'vars'}{'point2count'},
				$$$alldata{$varname}{'vars'}{'point1count'} . "\n\n";
	}

	if($2 eq "Hourly")
	{
		$hourlydevcount = $hourlydevcount + $$$alldata{$varname}{'vars'}{'point1count'};
		$hourlydevcount10 = $hourlydevcount10 + $$$alldata{$varname}{'vars'}{'point5count'};
	}

	elsif($2 eq "Daily")
	{
		$dailydevcount = $dailydevcount + $$$alldata{$varname}{'vars'}{'point1count'};
		$dailydevcount10 = $dailydevcount10 + $$$alldata{$varname}{'vars'}{'point5count'};
	}
	
	elsif($2 eq "Monthly")
	{
		$monthlydevcount = $monthlydevcount + $$$alldata{$varname}{'vars'}{'point1count'};
		$monthlydevcount10 = $monthlydevcount10 + $$$alldata{$varname}{'vars'}{'point5count'};
	}

	elsif($2 eq "RunPeriod")
	{
		$runperioddevcount = $runperioddevcount + $$$alldata{$varname}{'vars'}{'point1count'};
		$runperioddevcount10 = $runperioddevcount10 + $$$alldata{$varname}{'vars'}{'point5count'};
	}
}

open(RESULTS, ">qareport.txt");
print RESULTS "Number of Dev Points: " .  $hourlydevcount . "\t" . $dailydevcount . "\t" . $monthlydevcount . "\t" . $runperioddevcount . "\n";
print RESULTS "Number of Dev Points 10: " .  $hourlydevcount10 . "\t" . $dailydevcount10 . "\t" . $monthlydevcount10 . "\t" . $runperioddevcount10 ."\n";
print RESULTS "Total number of Data Points: " .  $totalhourlydatapoints . "\t" . $totaldailydatapoints . "\t" . $totalmonthlydatapoints . "\t" . $totalrunperioddatapoints . "\n";

if ($totalhourlydatapoints != 0)
{	$hp = $hourlydevcount/$totalhourlydatapoints * 100; 
	$hp10 = $hourlydevcount10/$totalhourlydatapoints * 100; }
else
{	$hp = 0; 
	$hp10 = 0; }

if($totaldailydatapoints != 0)
{	$dp = $dailydevcount/$totaldailydatapoints * 100; 
	$dp10 = $dailydevcount10/$totaldailydatapoints * 100; }
else
{	$dp = 0;
	$dp10 = 0;}

if($totalmonthlydatapoints != 0)
{	$mp = $monthlydevcount/$totalmonthlydatapoints * 100;
	$mp10 = $monthlydevcount10/$totalmonthlydatapoints * 100;}
else
{	$mp = 0;
	$mp10 = 0;}

if($totalrunperioddatapoints != 0)
{	$rp = $runperioddevcount/$totalrunperioddatapoints * 100;
	$rp10 = $runperioddevcount10/$totalrunperioddatapoints * 100;}
else
{	$rp = 0;
	$rp10 = 0;}

#print RESULTS "Dev Percentage: " .  $hp . "\t" . $dp . "\t" . $mp . "\t" . $rp . "\n";

#printf RESULTS  "Dev Percentage: %.2f\t%.2f\t%.2f\t%.2f\n", $hp, $dp, $mp, $rp;
printf RESULTS  "Dev Percentage 1: %.2f\n", $hp;
printf RESULTS  "Dev Percentage 10: %.2f\n", $hp10;
print "\nMaxdev name: " . $maxname;
print "\nMaxdev ID: " . $maxid;
print "\nMaxdev value: " . $maxdev;
print "\nMax line num:" . $maxlinenum;
print "\n";
=cut
$varname = "Gas:Facility [J] !Hourly [Value,Min,Minute,Max,Minute]";
print "\n\nMonthly deviation distribution for $varname:\n";
for($m=1;$m<13;$m++)
{
        if($$$alldata{$varname}{'devinmonthpoint1'}[$m] == "")
        {
                $$$alldata{$varname}{'devinmonthpoint1'}[$m] = 0;
        }


                printf "%5s", $$$alldata{$varname}{'devinmonthpoint1'}[$m];
}
print "\n\n";
for($m=1;$m<13;$m++)
{
        if($$$alldata{$varname}{'devinmonthpoint2'}[$m] == "")
        {
                $$$alldata{$varname}{'devinmonthpoint2'}[$m] = 0;
        }

                printf "%5s", $$$alldata{$varname}{'devinmonthpoint2'}[$m];

}

print "\n\n";
for($m=1;$m<13;$m++)
{

        if($$$alldata{$varname}{'devinmonthpoint3'}[$m] == "")
        {
                $$$alldata{$varname}{'devinmonthpoint3'}[$m] = 0;
        }


                printf "%5s", $$$alldata{$varname}{'devinmonthpoint3'}[$m];
}
print "\n\n";
for($m=1;$m<13;$m++)
{

        if($$$alldata{$varname}{'devinmonthpoint4'}[$m] == "")
        {
                $$$alldata{$varname}{'devinmonthpoint4'}[$m] = 0;
        }


                printf "%5s", $$$alldata{$varname}{'devinmonthpoint4'}[$m];
}
print "\n\n";
for($m=1;$m<13;$m++)
{

        if($$$alldata{$varname}{'devinmonthpoint5'}[$m] == "")
        {
                $$$alldata{$varname}{'devinmonthpoint5'}[$m] = 0;
        }

                printf "%5s", $$$alldata{$varname}{'devinmonthpoint5'}[$m];
}

print "\n\n";
=cut
