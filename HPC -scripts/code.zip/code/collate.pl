#!/usr/bin/perl5.10.1
use Switch;
use POSIX qw(ceil floor);

if( $#ARGV +1 < 1 )
{
        print "You must mention the IDF file name\n";
        print "Usage: ./collate.pl <IDFname>\n\n";
        exit;

}

open(INFILE1, 	"<Output1/$ARGV[0]1.eso"	);
open(INFILE2, 	"<$ARGV[0]2.eso"	);
open(INFILE3, 	"<$ARGV[0]3.eso"	);
open(INFILE4, 	"<$ARGV[0]4.eso"	);
open(INFILE5,	"<$ARGV[0]5.eso"	);
open(INFILE6, 	"<$ARGV[0]6.eso"	);
open(INFILE7, 	"<$ARGV[0]7.eso"	);
open(INFILE8, 	"<$ARGV[0]8.eso"	);
open(INFILE9, 	"<$ARGV[0]9.eso"	);
open(INFILE10,	"<$ARGV[0]10.eso"	);
open(INFILE11,	"<$ARGV[0]11.eso"	);
open(INFILE12,	"<$ARGV[0]12.eso"	);
#open(INFILE12,	"<Output12/$ARGV[0]12.eso"	);

open(OUTFILE,">sorted_final.eso");


# Storing file contents in array. High memory usage.
@file1  = <INFILE1>  ;
@file2  = <INFILE2>  ;
@file3  = <INFILE3>  ;
@file4  = <INFILE4>  ;
@file5  = <INFILE5>  ;
@file6  = <INFILE6>  ;
@file7  = <INFILE7>  ;
@file8  = <INFILE8>  ;
@file9  = <INFILE9>  ;
@file10 = <INFILE10> ;
@file11 = <INFILE11> ;
@file12 = <INFILE12> ;

########################################################################################################
				# dealing with runperiod vars #
########################################################################################################
`rm -f runperiodvarsnew.txt runperiodvarsdoublenew.txt; touch runperiodvarsnew.txt runperiodvarsdoublenew.txt`;
############# 1. Read the runperiodvars files, find the zones-runperiod variable combinations from ESO and write these combinations to new files
open(RPDFILETEMP,"<runperiodvarsdouble.txt" ); 	#stores the names of runperiod varaible which are now converted to monthly variables and 
						#their names are same as one of the run period variables

open(RPFILETEMP,"<runperiodvars.txt" );		#stores the names of runperiod varaible which are now converted to monthly variables and 
						#are not in above file
@rpfiletemp  = <RPFILETEMP>;
@rpdfiletemp = <RPDFILETEMP>;

for($i=0;$i<scalar(@rpfiletemp) ;$i++)
{
chomp($rpfiletemp[$i]);

system('grep "' . $rpfiletemp[$i] . '" Output1/*1.eso | grep -i "monthly" | egrep -o "([a-zA-Z][a-zA-Z0-9_ :-]+)?,' . $rpfiletemp[$i] . '( *\[[^\5B]*\])?( )?\!" | sed "s/^,//" | sed "s/[ \!]*$//" >> runperiodvarsnew.txt');
}
print "\nHello2\n";
for($i=0;$i<scalar(@rpdfiletemp) ;$i++)
{
chomp($rpdfiletemp[$i]);
system('grep "' . $rpdfiletemp[$i] . '" Output1/*1.eso | grep -i "monthly" | egrep -o "([a-zA-Z][a-zA-Z0-9_ :-]+)?,' . $rpdfiletemp[$i] . '( *\[[^\5B]*\])?( )?\!" | sed "s/[ \!]*$//" | sed "s/^,//" >> runperiodvarsdoublenew.txt');
}
############# 2. Read these new files, and store the variable names in perl variables

open(RPFILE,"<runperiodvarsnew.txt" );
@rpfile = <RPFILE>;

for($i=0;$i<scalar(@rpfile) ;$i++)
{
	$rpfile[$i] =~ /^ *([^\n]*)/;
	$rpvarsname[$i] = $1;
#	print $1 . "\n";
}
print "Total number: $i \n\n";


open(RPDFILE,"<runperiodvarsdoublenew.txt" );
@rpdfile = <RPDFILE>;

$firstrpdid = 9999;
for($i=0;$i<scalar(@rpdfile) ;$i++)
{
	$rpdfile[$i] =~ /^ *([^\n]*)/;
	$rpdvarsname[$i] = $1;
	$rpdvarsid[$i] = $firstrpdid -- ;

#	print "\n" . $rpdvarsname[$i];
	
#	$curvarname = $rpdvarsname[$i];
#	$curline = chomp($rpdfile[$i]);
#	exec( "grep \"" . $curvarname . "\" " . $curline );
}

print "Total number: $i \n\n";




###########################################################################################################

#exit();
#Cummulative days to be filled in month record header. May be these days can be calculated in the same way as calculated for hour header "^2,"
$days_cum[1] = 31;
$days_cum[2] = 59; 
$days_cum[3] = 90; 
$days_cum[4] = 120; 
$days_cum[5] = 151; 
$days_cum[6] = 181; 
$days_cum[7] = 212; 
$days_cum[8] = 243; 
$days_cum[9] = 273; 
$days_cum[10] = 304; 
$days_cum[11] = 334; 
$days_cum[12] = 365; 
 
###########################################################################################################
				# Read and modify data dictionary #
###########################################################################################################
$numHourly = 0;  	# number of hourly variables
$numDaily = 0;
$numMonthly = 0;	# number of monthly variables
$i	= 1;		
$hours 	= 0;
$days = 0;
#@rpvars = ("478" , "12150" , "13241");		# runperiod variables. To be filled manually.

$designDayCount = ( `grep -c "^1," Output1/$ARGV[0]1.eso` - 2 );#Number of headers starting with one, minus 2 (1 for data dictionary & 1 for actual data)


@rpvars = (); #"6967");  #and @rpvarsname stores the name of each variable
@rpdvars = ();
print "Check point 0\n";
for($m=0;;$m++)					# Iterate over the data dictionary of 1st eso
{

	#$file1[$m] =~ s/Monthly/RunPeriod/;

	$_ = $file1[$m];			# $_ = one line of 1st eso

	print "\n$_\n";
	
	if(/^End of Data Dictionary/)	
	{
		$lineNumEndDDic = $m;		# Data dictionary ending line number
	}

	if(/!Hourly/)
	{
		$numHourly++;			# Number of hourly variables
	}

        if(/!Daily/)
        {
                $numDaily ++;                   # Number of hourly variables
        }

	if(/!Monthly/)
	{

		$numMonthly++;			# Number of monthly variables

		for($i=0;$i<scalar(@rpdvarsname) ;$i++)
		{
			$t = $rpdvarsname[$i];
			$t =~ s/\[/\\\[/; #replace ']' with '\]' so that substring matching in the 'if' condition works otherwise ']' is taken as special
			$t =~ s/\]/\\\]/;

        		if($file1[$m] =~ /$t/)
			{
				$file1[$m] =~ /^([0-9]+),/;	
				$rpdvars[$i] = $1;
			print OUTFILE "$rpdvarsid[$i],7,$rpdvarsname[$i] !RunPeriod [Value,Min,Month,Day,Hour,Minute,Max,Month,Day,Hour,Minute]\n";

				last;
		      	}
        	}

		for($i=0;$i<scalar(@rpvarsname) ;$i++)
		{
			#print "\nJust processed " . $rpvarsname[$i] ;	
			$t = $rpvarsname[$i];
			$t =~ s/\[/\\\[/; #replace ']' with '\]' so that substring matching in the 'if' condition works otherwise ']' is taken as special
			$t =~ s/\]/\\\]/;
			if($file1[$m] =~ /$t/i)
			{
				$file1[$m] =~ /^([0-9]+),/;	
				$rpvars[$i] = $1;
				$file1[$m] =~ s/Monthly/RunPeriod/;
				$file1[$m] =~ s/Day,Hour,Minute/Month,Day,Hour,Minute/g;
				last;
			}
		}
        
	}
	
	print OUTFILE $file1[$m];

	if(/^1,[^0-9]/)			# break the loop when 1st design day starts.
	{
		last;
	}

	$i++;
}
##############################################################################################
#exit();
#print "\n\n";
#foreach(@rpvarsname)
#{
#        print $_ . "\n";
#}
#exit;

#print "\n\n";
#foreach(@rpvars)
#{
#	print $_ . "\n";
#}
#exit;

#################################################################################################################
					# Dealing with Design Day #
#################################################################################################################
print "\nDesign day Count: " . $designDayCount . "\n";



for( $g=0; $g< $designDayCount; $g++) #Iterate over each design day
{

	$m++;	# To skip over the 1st line of 1st design day "^1,CHICAGO" because it will be printed by the print line in the above loop
	print "Check point 1\n";
	$i_var = 0;	#index for @rpvars
	OUTERFOR5: for(;;$m++)				# iterate over the current(the one being processed by this iteration) design day of 1st eso
	{
		$_ = $file1[$m];

		
		for($u=0; $u< scalar(@rpvars); $u++)
		{
			$t = $_;
			$t =~ s/\[/\\\[/; #replace ']' with '\]' so that substring matching in the 'if' condition works otherwise ']' is taken as special
			$t =~ s/\]/\\\]/;

			if($t =~ /^$rpvars[$u],/)		# if the line is runperiod variable line stored in the form of monthly variable
			{				# put the month number also so that it can be stored in runperiod section

				#insert code here to parse the line
				s/^([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*)/\1,\2,\3, 1,\4,\5,\6,\7, 1/;

				$save_line[$i_var] = $_;
				$i_var++;
				next OUTERFOR5;
			}
		}

		for($u=0; $u< scalar(@rpdvars); $u++)
		{

			$t = $_;
			$t =~ s/\[/\\\[/; #replace ']' with '\]' so that substring matching in the 'if' condition works otherwise ']' is taken as special
			$t =~ s/\]/\\\]/;
			$t =~ s/\//\\\//;			

			if($t =~ /^$rpdvars[$u],/)		# if the line is runperiod variable line stored in the form of monthly variable
			{				# put the month number also so that it can be stored in runperiod section
				$temp_ = $_;
				
				#modify the line to make it a runperiod record
				if($temp_ =~ /^([-0-9E :.]*),([-0-9E :.]*)$/)
				{

#					$temp_ =~ s/^([-0-9E :.]*),([-0-9E :.]*)/$rpdvarsid[$u],$rpdvarsname[$u],\2/;
					$temp_ =~ s/^([-0-9E :.]*),([-0-9E :.]*)/$rpdvarsid[$u],\2/;
				}
				elsif($temp_ =~ /^([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*)/)
				{

#					$temp_ =~ s/^([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*)/$rpdvarsid[$u],$rpdvarsname[$u],\2,\3, 1,\4,\5,\6,\7, 1/;
					$temp_ =~ s/^([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*),([-0-9E :.]*)/$rpdvarsid[$u],\2,\3, 1,\4,\5,\6,\7, 1/;

				}
				else
				{
					print "\nRunPeriod variable format error\n";
					exit;
				}
			
				$save_line[$i_var] = $temp_;  #try changing this to:    $_ = $temp_;
				$i_var++;
				last;
				#next OUTERFOR5;
			}
		}




		if(/^1,/)			# break if 1st line of next design day found
		{
			#$last_line = $_;
			last;
		}

		print OUTFILE;
		$i++;

	}
	print "Check point 2\n";
	$lineNumEndDDay = $m + 1;
	#create the run period section

	if( scalar(@rpvars) >= 1 || scalar(@rpdvars) >= 1 )
	{
		print OUTFILE "5,1\n";

		for($h = 0; $h<(scalar(@rpvars) + scalar(@rpdvars)) ; $h++)
		{
			print OUTFILE $save_line[$h];
		}
	}
		###

	print "Check point 3\n";
	print OUTFILE $_;		# Print the "1,CHICAGO..." line because it is not printed in the loop (print line is skipped due to 'last')

}

print "In FILE1, Number of hourly variables: $numHourly\n";
print "In FILE1, Number of daily variables: $numDaily\n";
print "In FILE1, Number of monthly variables: $numMonthly\n";
print "In FILE1, Design day ends at $lineNumEndDDay \n";

##########################################################################################################

for($month=0;$month<12;$month++)	# Read ESO for each month
{
	$dayFromHour = 0;		#Number of days calculated from hourly header (varies from 0 to 31)
	$dayFromDay = 0;

	$current_month = $month + 1;	#Stores the month number starting from 1
	$flag_hourly=0;			#line number of the 1st hourly header for a particular month
	$flag_daily=0;			#line number of the 1st daily header for a particular month
	$flag_monthly[0]=0;		#line number of the monthly header for 1st month
	$flag_monthly[1]=0;		#line number of the monthly header for any other month

	$numMonthlyData = 0;
	$numDailyData = 0;
	$numHourlyData = 0;

	$next_month = $current_month + 1;

	switch($current_month)
	{
		case(1)		{$fileref = \@file1;}
		case(2)		{$fileref = \@file2;}
		case(3)		{$fileref = \@file3;}
		case(4)		{$fileref = \@file4;}
		case(5)		{$fileref = \@file5;}
		case(6)		{$fileref = \@file6;}
		case(7)		{$fileref = \@file7;}
		case(8)		{$fileref = \@file8;}
		case(9)		{$fileref = \@file9;}
		case(10)	{$fileref = \@file10;}
		case(11)	{$fileref = \@file11;}	
		case(12)	{$fileref = \@file12;}
	}

	print "\n\nMonth being processed: $current_month\n";
	#print "\n\n$lineNumEndDDay\n\n";

########################################################################################################
  			# Store line numbers for hourly start, monthly start, etc #
########################################################################################################
	for($j=$lineNumEndDDay + 1 ;  ; $j++)	# Start from 1st line of the real data 
	{					# and notedown the start of hourly/monthly variables


		if($$fileref[$j-1] =~ /^2,[0-9]*,( )?${current_month},[0-9 ]*,[0-9 ]*, 1,/) #($flag_hourly!=1) ) # matches first hour record of everyday
		{	
		#if first hourly header of the month whose file is being read. 
		#(It won't take the month with warmup days because the actual month number is directly mentioned)

			#2,Day of Simulation,Month,Day of Month, ...
			$dayFromHour++;				
			$hourly_start[$dayFromHour] = $j;			# line number of this hourly header
			$flag_hourly=1;				
			#$hours++;				 
		}

		if( ($$fileref[$j-1] =~ /^3,[0-9]*,( )?${current_month},/) )#&& ($flag_daily!=1) )
		{	
		#if first daily header of the month whose file is being read. 
		#(It won't take the month with warmup days because the actual month number is directly mentioned)

			#3,Day of Simulation,Month,Day of Month, ...
			$dayFromDay++;
			$daily_start[$dayFromDay] = $j;			# line number of the daily header
			$flag_daily=1;				
			#$days ++;
		}

		if($current_month == 1) 	# Jan month
		{
			if( ($$fileref[$j-1] =~ /^4,[ 0-9]*, 1/) && ($flag_monthly[0]!=1) )
			{
				# 4,Cumulative Days of Simulation,Month
				$flag_monthly[0]  =  1;	
				$monthly_start[0] = $j;		# line number of the monthly header for this month
			}
		}
		
		else	# For other months
		{
			if( ($$fileref[$j-1] =~ /^4,[ 0-9]*,( )?$month/) && ($flag_monthly[0]!=1) )
			{ # I guess, this can be removed
			
				# 4,Cumulative Days of Simulation,Month
				$flag_monthly[0]=1;		# not needed now
				$monthly_start[0]=$j;			
			}

			elsif( ($$fileref[$j-1] =~ /^4,[ 0-9]*,( )?$current_month/) && ($flag_monthly[1]!=1) )
			{
				# This condition won't be met for jan
				$flag_monthly[1]=1;		# not needed now
				$monthly_start[1]=$j;		# line number of the monthly header for this month
			}
		}
	
		if(     $$fileref[$j-1] =~ /^End of Data/ || ($$fileref[$j-1] =~ /^2,[0-9]*,( )?${next_month},/)
			|| ($$fileref[$j-1] =~ /^3,[0-9]*,( )?${next_month},/)
			|| ($$fileref[$j-1] =~ /^4,[0-9]*,( )?${next_month},/)
			#($flag_hourly  && $flag_monthly[0] && $current_month==1)  #for jan
			#|| 
			#($flag_hourly  && $flag_monthly[0] && $flag_monthly[1])

		  )
		{ #Break if both monthly and hourly data is read
			last;
		}
	}

##################################################################################################################

	print "Check point 6\n";
	
	print "File$current_month: Hourly values start at $hourly_start \n";
	print "File$current_month: Daily values start at $daily_start \n";
	print "File$current_month: Monthly1 starts at ${monthly_start[0]} \n";
	if($current_month != 1)
	{
		print "File$current_month: Monthly2 starts at ${monthly_start[1]} \n";
	}
##################################################################################################################
					# print hourly, daily and monthly sections   #
##################################################################################################################	
############# 1. Hourly variables
	for($t=1;$t<$dayFromHour+1;$t++)
	{
		if( ($$fileref[$hourly_start[$t]-1] =~ /^2,/) && ($flag_hourly == 1) )  ## correcting the header
		{	
			$hours++;
			$temp = ceil($hours/24);
			$$fileref[$hourly_start[$t]-1] =~ s/^2,( )?[0-9]*/2,${temp}/;	
		}
		
		if($flag_hourly == 1)
		{
			print OUTFILE $$fileref[$hourly_start[$t]-1];		#Print the hourly header

			#print $$fileref[$hourly_start-1];
			for($k= $hourly_start[$t] + 1 ; ; $k++)			#Iterate through hourly variables and print them
			{
				
				if($$fileref[$k-1] =~ /^2,[0-9 ]*,[0-9 ]*,( )?$t/)
				{	
					$hours++;
					$temp = ceil($hours/24);
					$$fileref[$k-1] =~ s/^2,( )?[0-9]*/2,${temp}/;			#Store the correct cummulative day val
				}

				elsif( $$fileref[$k-1] =~ /^[12345],/) # If the statement matches to some daily/monthly/runperiod header OR if it 
								       # matches hourly header(for some other day) then break the loop
				{
					print "File$current_month: Non-hourly found at $k\n";
					last;
				}
				print OUTFILE $$fileref[$k-1];
				$numHourlyData ++;
			}
		}



		if( ($$fileref[$daily_start[$t]-1] =~ /^3,/) && ($flag_daily == 1) )  ## correcting the header
		{	
			$days++;
			# $hours++;
			# $temp = ceil($hours/24);
			$$fileref[$daily_start[$t]-1] =~ s/^3,( )?[0-9]*/3,${days}/;	
		}

		
		if($flag_daily == 1)
		{
			print OUTFILE $$fileref[$daily_start[$t]-1];		#Print the daily header
			#print $$fileref[$hourly_start-1];
			for($k= $daily_start[$t] + 1 ; ; $k++)			#Iterate through daily variables and print them
			{
				
				if($$fileref[$k-1] =~ /^3,[0-9 ]*,[0-9 ]*,( )?$t/)
				{	
					#$hours++;
					$days ++;
					$$fileref[$k-1] =~ s/^3,( )?[0-9]*/3,${days}/;			#Store the correct cummulative day val
				}
				elsif($$fileref[$k-1] =~ /^[12345],/)
				{
					print "File$current_month: Non-daily found at $k\n";
					last;
				}
				print OUTFILE $$fileref[$k-1];
				$numDailyData ++;
			}
		}

	}


	print "Check point 7\n";
################ 2.  Monthly variables(and also the ones converted from runperiod variables) for 1st file. 
			#Condition needed bcoz 1st file contains no warmup days
	if($current_month == 1 && ($flag_monthly[0] == 1) )
	{

		
		print OUTFILE $$fileref[$monthly_start[0]-1];		#Print monthly header ( ^4, ... )
			
		OUTERFOR: for($k= $monthly_start[0] + 1 ; ; $k++) # Iterate over the monthly variables, and see if any one of them is a runperiod var
		{						  # If yes, store it. If not, print it

			if($$fileref[$k-1] =~ /(^[12345],)|(^End of Data)/) #Break if non-monthly data found
			{
				print "File$current_month: Non-monthly1 found at $k\n";
				last;
			}


			for($i=0; $i< scalar(@rpvars); $i++)
			{

				if($$fileref[$k-1] =~ /^$rpvars[$i],/) #if runperiod variable found, parse it and store values in variables
				{

				($temp_months[$month][0][$i], $temp_months[$month][1][$i], $temp_months[$month][2][$i], $temp_months[$month][3][$i], 
				$temp_months[$month][4][$i], $temp_months[$month][5][$i], $temp_months[$month][6][$i], $temp_months[$month][7][$i], 
					$temp_months[$month][8][$i]) = 
						($$fileref[$k-1] =~ 
		/^$rpvars[$i],([-0-9E :.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+)/);

						next OUTERFOR;  
				}			
			}

=cut
			for($j=0; $j< scalar(@rpdvars); $j++)
			{

				if($$fileref[$k-1] =~ /^$rpdvars[$j],/) #if runperiod variable found, parse it and store values in variables
				{

				($temp_months[$month][0][$i+$j], $temp_months[$month][1][$i+$j], $temp_months[$month][2][$i+$j], 
				$temp_months[$month][3][$i+$j], $temp_months[$month][4][$i+$j], $temp_months[$month][5][$i+$j], 
				$temp_months[$month][6][$i+$j], $temp_months[$month][7][$i+$j], $temp_months[$month][8][$i+$j]) = 
						($$fileref[$k-1] =~ 
		/^$rpdvars[$j],([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+)/);

						last;
				}			
			}
=cut

			for($j=0;$j<scalar(@rpdvars);$j++) #if runperiod variable found, parse it and store values in variables
			{

				if($$fileref[$k-1] =~ /^$rpdvars[$j],/)
				{

					if($$fileref[$k-1] =~ 
	/^$rpdvars[$j],([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+)/)
					{	
						$temp_months[$month][0][$i+$j] = $1;
						$temp_months[$month][1][$i+$j] = $2; 
						$temp_months[$month][2][$i+$j] = $3;
						$temp_months[$month][3][$i+$j] = $4; 
						$temp_months[$month][4][$i+$j] = $5;
						$temp_months[$month][5][$i+$j] = $6;
						$temp_months[$month][6][$i+$j] = $7;
						$temp_months[$month][7][$i+$j] = $8;
						$temp_months[$month][8][$i+$j] = $9; 
if( $rpdvarsid[$j] == "9989" && $month == 0 )
{
#	print "\nMonth $month: " . $temp_months[$month][0][$i + $j]. "\n";
	print "\n" . $$fileref[$k-1] . "\n" ;
}

					}
					elsif($$fileref[$k-1] =~ /^$rpdvars[$j],([-0-9 E:.]+)/)
					{
						$temp_months[$month][0][$i+$j] = $1; 
						$temp_months[$month][1][$i+$j] = ""; 
						$temp_months[$month][2][$i+$j] = "";
						$temp_months[$month][3][$i+$j] = ""; 
						$temp_months[$month][4][$i+$j] = "";
						$temp_months[$month][5][$i+$j] = "";
						$temp_months[$month][6][$i+$j] = "";
						$temp_months[$month][7][$i+$j] = "";
						$temp_months[$month][8][$i+$j] = ""; 
if( $rpdvarsid[$j] == "9989" && $month == 0 )
{
#	print "\nMonth $month: " . $temp_months[$month][0][$i + $j]. "\n";
	print "\n" . $$fileref[$k-1] . "\n" ;
}
					}

#					if ( $rpdvars[$i]					


					last;
				}

			}








			# if the line is not for a runperiod var, print it (it will go under monthly section)
			print OUTFILE $$fileref[$k-1];
			$numMonthlyData ++;
		}
	}
	

############## 3. Monthly variables(and the ones converted from runperiod variables) for rest of the files
	elsif($flag_monthly[1] == 1) 
	{
		$$fileref[$monthly_start[1]-1] =~ s/^4,( )?[0-9]*/4,${days_cum[$current_month]}/;	#replace with correct number of cummulative days
		print OUTFILE $$fileref[$monthly_start[1]-1];		#Print monthly header ( ^4, ... )
		OUTERFOR2: for($k= $monthly_start[1] + 1 ; ; $k++) #Iterate over the monthly variables, and see if any one of them is a runperiod var
		{
			if($$fileref[$k-1] =~ /(^[12345],)|(^End of Data)/)
			{
				print "File$current_month: Non-monthly2 found at $k\n";
				last;
			}

			for($i=0;$i<scalar(@rpvars);$i++) #if runperiod variable found, parse it and store values in variables
			{

				if($$fileref[$k-1] =~ /^$rpvars[$i],/)
				{

					if($$fileref[$k-1] =~ 
	/^$rpvars[$i],([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+)/)
					{	
						$temp_months[$month][0][$i] = $1;
						$temp_months[$month][1][$i] = $2; 
						$temp_months[$month][2][$i] = $3;
						$temp_months[$month][3][$i] = $4; 
						$temp_months[$month][4][$i] = $5;
						$temp_months[$month][5][$i] = $6;
						$temp_months[$month][6][$i] = $7;
						$temp_months[$month][7][$i] = $8;
						$temp_months[$month][8][$i] = $9; 
					}
					elsif($$fileref[$k-1] =~ /^$rpvars[$i],([-0-9 E:.]+)/)
					{
						$temp_months[$month][0][$i] = $1; 
						$temp_months[$month][1][$i] = ""; 
						$temp_months[$month][2][$i] = "";
						$temp_months[$month][3][$i] = ""; 
						$temp_months[$month][4][$i] = "";
						$temp_months[$month][5][$i] = "";
						$temp_months[$month][6][$i] = "";
						$temp_months[$month][7][$i] = "";
						$temp_months[$month][8][$i] = ""; 
					}
				
					#print "\n\n" . $temp_months[$month][0][$i] . "\n";
					next OUTERFOR2;
				}
			}
#$i = 0;
			for($j=0;$j<scalar(@rpdvars);$j++) #if runperiod variable found, parse it and store values in variables
			{

				if($$fileref[$k-1] =~ /^$rpdvars[$j],/)
				{

					if($$fileref[$k-1] =~ 
	/^$rpdvars[$j],([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+)/)
					{	
						$temp_months[$month][0][$i+$j] = $1;
						$temp_months[$month][1][$i+$j] = $2; 
						$temp_months[$month][2][$i+$j] = $3;
						$temp_months[$month][3][$i+$j] = $4; 
						$temp_months[$month][4][$i+$j] = $5;
						$temp_months[$month][5][$i+$j] = $6;
						$temp_months[$month][6][$i+$j] = $7;
						$temp_months[$month][7][$i+$j] = $8;
						$temp_months[$month][8][$i+$j] = $9; 
if( $rpdvarsid[$j] == "9989" && $month == 1 )
{
#	print "\nMonth $month: " . $temp_months[$month][0][$i + $j]. "\n";
	print "\n" . $$fileref[$k-1] . "\n" ;
}

					}
					elsif($$fileref[$k-1] =~ /^$rpdvars[$j],([-0-9 E:.]+)/)
					{
						$temp_months[$month][0][$i+$j] = $1; 
						$temp_months[$month][1][$i+$j] = ""; 
						$temp_months[$month][2][$i+$j] = "";
						$temp_months[$month][3][$i+$j] = ""; 
						$temp_months[$month][4][$i+$j] = "";
						$temp_months[$month][5][$i+$j] = "";
						$temp_months[$month][6][$i+$j] = "";
						$temp_months[$month][7][$i+$j] = "";
						$temp_months[$month][8][$i+$j] = ""; 
if( $rpdvarsid[$j] == "9989" && $month == 1 )
{
#	print "\nMonth $month: " . $temp_months[$month][0][$i + $j]. "\n";
	print "\n" . $$fileref[$k-1] . "\n" ;
}
					}

#					if ( $rpdvars[$i]					


					last;
				}


=cut

				if($$fileref[$k-1] =~ /^$rpdvars[$j],/)
				{
		($temp_months[$month][0][$i+$j]) = ($$fileref[$k-1] =~ /^$rpdvars[$j],([-0-9 E:.]+)/); 
				
		($temp_months[$month][0][$i+$j], $temp_months[$month][1][$i+$j], $temp_months[$month][2][$i+$j], $temp_months[$month][3][$i+$j], 
		$temp_months[$month][4][$i+$j], $temp_months[$month][5][$i+$j], $temp_months[$month][6][$i+$j], $temp_months[$month][7][$i+$j], 
		$temp_months[$month][8][$i+$j]) = 
($$fileref[$k-1] =~ /^$rpdvars[$j],([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+),([-0-9 E:.]+)/); 

		if( $rpdvars[$j] == 568 )
		{
			print "\nQQQQQQQQQQ: " . $temp_months[$month][0][$i+$j] . "\n\n" ;
			#print ".\n" .$$fileref[$k-1] ."\n\n" ;
		}
				#print "\n\n" . $temp_months[$month][0][$i] . "\n";
				
					last;
				}
=cut

			}

			# if the line is not for a run period var, print it (it will go under monthly section)
			print OUTFILE $$fileref[$k-1];
			$numMonthlyData ++;
		}
	}
############################################################################################################
	print "File$current_month: Number of hourly records $numHourlyData \n";
	print "File$current_month: Number of daily records $numDailyData \n";
	print "File$current_month: Number of monthly records $numMonthlyData \n";

	print "\n$month processed";	
}   ## finished iterating over the 12 files


$sum_annual{'sum'}[0] = 0;

for($month=0;$month<12;$month++)
{
	$sum_annual{'sum'}[0] += $temp_months[$month][0][0];
}
print $rpdvars[0] . ", " . $rpdvarsid[0] . ", " . $rpdvarsname[0] . ", " .  $sum_annual{'sum'}[0]/12 . "\n\n"; 
#exit;


#############################################################################################################
					# print runperiod section #
#############################################################################################################
if( ( scalar(@rpvars) >= 1) || (scalar(@rpdvars) >= 1)) #If run period variables exist
{
	print OUTFILE "5,365\n";
}
$i = 0;

if( scalar(@rpvars) >= 1 ) #If single time occuring run period variables exist
{
	$month_min = $month_max = 0;
	for($i=0;$i<scalar(@rpvars);$i++)		# print run period variables
	{
		$sum_annual{'sum'}[$i] = 0;
		$sum_annual{'maxval'}[$i] = 9999999999;
		$sum_annual{'minval'}[$i] = -9999999999;

		for($month=0;$month<12;$month++)
		{

			$sum_annual{'sum'}[$i] += $temp_months[$month][0][$i];
	
			if ( $rpvars[$i] == 568 ) 
			{
				print "\n\n" . $temp_months[$month][0][$i]. "\n\n";

			}
		

			if( $sum_annual{'maxval'}[$i] >  $temp_months[$month][1][$i] )		
			{
				$sum_annual{'maxval'}[$i] = $temp_months[$month][1][$i];
				$sum_annual{'maxday'}[$i] = $temp_months[$month][2][$i];
				$sum_annual{'maxhour'}[$i] = $temp_months[$month][3][$i];
				$sum_annual{'maxminute'}[$i] = $temp_months[$month][4][$i];						
				$month_min = $month + 1;
			}
			if( $sum_annual{'minval'}[$i] <  $temp_months[$month][5][$i] )
			{
				$sum_annual{'minval'}[$i] = $temp_months[$month][5][$i];
				$sum_annual{'minday'}[$i] = $temp_months[$month][6][$i];
				$sum_annual{'minhour'}[$i] = $temp_months[$month][7][$i];
				$sum_annual{'minminute'}[$i] = $temp_months[$month][8][$i];						
				$month_max = $month + 1;
			}
		}
		
# if($rpvarsname[$i] =~ /\[C\]/ || $rpvarsname[$i] =~ /\[%\]/  )  #if the variable is a temperature variable, take average otherwise take sum


                if(     $rpvarsname[$i] =~ /\[C\]/ ||
                        $rpvarsname[$i] =~ /\[%\]/ || 
                        $rpvarsname[$i] =~ /\[ach\]/ || 
                        $rpvarsname[$i] =~ /\[lux\]/ || 
                        $rpvarsname[$i] =~ /\[Pa\]/ || 
                        $rpvarsname[$i] =~ /\[mm\]/ || 
                        $rpvarsname[$i] =~ /\[m2\]/ || 
                        $rpvarsname[$i] =~ /\[lum\/W\]/ || 
                        $rpvarsname[$i] =~ /\[m\/s\]/ ||
                        $rpvarsname[$i] =~ /\[deg\]/ ||
                        $rpvarsname[$i] =~ /\[W\/m2\]/ ||
                        $rpvarsname[$i] =~ /\[J\/kg\]/ ||
                        $rpvarsname[$i] =~ /\[kg\/s\]/ ||
                        $rpvarsname[$i] =~ /\[kg\/m3\]/ || 
                        $rpvarsname[$i] =~ /\[kgWater\/kgAir\]/ || 
                        $rpvarsname[$i] =~ /\[m3\/s\]/ || 
                        $rpvarsname[$i] =~ /\[kgWater\/s\]/ || 
                        $rpvarsname[$i] =~ /\[W\/m2-K\]/ ||  
                        $rpvarsname[$i] =~ /\[\]/ ||      
                        $rpvarsname[$i] =~ /Angle/ ||
                        $rpvarsname[$i] =~ /Total Shortwave Radiation Absorbed on Inside of Surface\[W\]/ ||
                        $rpvarsname[$i] =~ /Window Solar Absorbed:All Glass Layers \[W\]/ ||
                        $rpvarsname[$i] =~ /Window Transmitted Diffuse Solar \[W\]/ ||
                        $rpvarsname[$i] =~ /Rate/ ||
                        $rpvarsname[$i] =~ /Performance Curve Output/ ||
                        $rpvarsname[$i] =~ /Plant Loop Heating Demand/ ||
                        $rpvarsname[$i] =~ /Plant Loop Cooling Demand/ ||
                        $rpvarsname[$i] =~ /Fan Electric Power/ ||
                        $rpvarsname[$i] =~ /AirLoopHVAC Actual Outdoor Air Fraction/ ||
                        $rpvarsname[$i] =~ /Plant Loop Unmet Demand/ ||
                        $rpvarsname[$i] =~ /Chiller COP/ ||
                        $rpvarsname[$i] =~ /Window Transmitted Solar/ ||
                        $rpvarsname[$i] =~ /Total Shortwave Absorbed:All Glass Layers \[W\]/ ||
                        $rpvarsname[$i] =~ /Status/ ||
                        $rpvarsname[$i] =~ /Fraction/ ||
                        $rpvarsname[$i] =~ /Lights Electric Power/ ||
                        $rpvarsname[$i] =~ /Ratio/ )  #for these kind of variables, take average otherwise take sum



		{
			$temp_ = $sum_annual{'sum'}[$i]/12;
		}
		else
		{
			$temp_ = $sum_annual{'sum'}[$i];
		}
		if(
			$sum_annual{'maxval'}[$i] eq "" && $sum_annual{'maxday'}[$i] eq "" && $sum_annual{'maxhour'}[$i] eq "" &&
			$sum_annual{'maxminute'}[$i] eq "" && $sum_annual{'minval'}[$i] eq "" && $sum_annual{'minday'}[$i] eq "" &&
			$sum_annual{'minhour'}[$i] eq "" && $sum_annual{'minminute'}[$i] eq ""
		) # If the variable does not contain min, max, etc attributes then no need to print them
		{
			print OUTFILE "$rpvars[$i],$temp_\n" ;
		}
		else
		{	
			print OUTFILE "$rpvars[$i],$temp_," . 
			      "$sum_annual{'maxval'}[$i],$month_min,$sum_annual{'maxday'}[$i],$sum_annual{'maxhour'}[$i],$sum_annual{'maxminute'}[$i]," . 			      "$sum_annual{'minval'}[$i],$month_max,$sum_annual{'minday'}[$i],$sum_annual{'minhour'}[$i],$sum_annual{'minminute'}[$i]\n";
		}
	}
}

if( scalar(@rpdvars) >= 1 ) #If 2 times occuring(for monthly n runperiod) run period variables exist
{
	$month_min = $month_max = 0;
	for($j=0;$j<scalar(@rpdvars);$j++)		# print run period variables
	{
		$sum_annual{'sum'}[$j] = 0;
		$sum_annual{'maxval'}[$j] = 9999999999;
		$sum_annual{'minval'}[$j] = -9999999999;

		for($month=0;$month<12;$month++)
		{
			#print $temp_months[$month][0][$i], ", ", $temp_months[$month][1][$i],", ", $temp_months[$month][2][$i],", ", $temp_months[$month][3][$i], ", ", $temp_months[$month][4][$i],", ", $temp_months[$month][5][$i],", ", $temp_months[$month][6][$i],", ", $temp_months[$month][7][$i],", ", $temp_months[$month][8][$i];
			#print "\n";

			$sum_annual{'sum'}[$j] += $temp_months[$month][0][$i+$j];
			if ( $rpdvarsid[$j] == 9989 ) 
			{
				print "\nMonth $month: " . $temp_months[$month][0][$i + $j]. "\n";
			#	print  $month . ":  " . $sum_annual{'sum'}[$j] . "\n";

			}


			if( $sum_annual{'maxval'}[$j] >  $temp_months[$month][1][$i+$j] )		
			{
				$sum_annual{'maxval'}[$j] = $temp_months[$month][1][$i+$j];
				$sum_annual{'maxday'}[$j] = $temp_months[$month][2][$i+$j];
				$sum_annual{'maxhour'}[$j] = $temp_months[$month][3][$i+$j];
				$sum_annual{'maxminute'}[$j] = $temp_months[$month][4][$i+$j];						
				$month_min = $month + 1;
			}
			if( $sum_annual{'minval'}[$j] <  $temp_months[$month][5][$i+$j] )
			{
				$sum_annual{'minval'}[$j] = $temp_months[$month][5][$i+$j];
				$sum_annual{'minday'}[$j] = $temp_months[$month][6][$i+$j];
				$sum_annual{'minhour'}[$j] = $temp_months[$month][7][$i+$j];
				$sum_annual{'minminute'}[$j] = $temp_months[$month][8][$i+$j];						
				$month_max = $month + 1;
			}
		}
			if ( $rpdvarsid[$j] == 9989 ) 
			{
			#	print "\n" . $temp_months[$month][0][$i + $j]. "\n";
			#	print  $sum_annual{'sum'}[$j] . "\n";

			}
	 	#print "\n\n" . $sum_annual{'sum'}[$j] . "\n\n";


                if(     $rpdvarsname[$j] =~ /\[C\]/ ||
                        $rpdvarsname[$j] =~ /\[%\]/ || 
                        $rpdvarsname[$j] =~ /\[ach\]/ || 
                        $rpdvarsname[$j] =~ /\[lux\]/ || 
                        $rpdvarsname[$j] =~ /\[Pa\]/ || 
                        $rpdvarsname[$j] =~ /\[mm\]/ || 
                        $rpdvarsname[$j] =~ /\[m2\]/ || 
                        $rpdvarsname[$j] =~ /\[lum\/W\]/ || 
                        $rpdvarsname[$j] =~ /\[m\/s\]/ ||
                        $rpdvarsname[$j] =~ /\[deg\]/ ||
                        $rpdvarsname[$j] =~ /\[W\/m2\]/ ||
                        $rpdvarsname[$j] =~ /\[J\/kg\]/ ||
                        $rpdvarsname[$j] =~ /\[kg\/s\]/ ||
                        $rpdvarsname[$j] =~ /\[kg\/m3\]/ || 
                        $rpdvarsname[$j] =~ /\[kgWater\/kgAir\]/ || 
                        $rpdvarsname[$j] =~ /\[m3\/s\]/ || 
                        $rpdvarsname[$j] =~ /\[kgWater\/s\]/ || 
                        $rpdvarsname[$j] =~ /\[W\/m2-K\]/ ||  
                        $rpdvarsname[$j] =~ /\[\]/ ||      
                        $rpdvarsname[$j] =~ /Angle/ ||
                        $rpdvarsname[$j] =~ /Total Shortwave Radiation Absorbed on Inside of Surface\[W\]/ ||
                        $rpdvarsname[$j] =~ /Window Solar Absorbed:All Glass Layers \[W\]/ ||
                        $rpdvarsname[$j] =~ /Window Transmitted Diffuse Solar \[W\]/ ||
                        $rpdvarsname[$j] =~ /Rate/ ||
                        $rpdvarsname[$j] =~ /Performance Curve Output/ ||
                        $rpdvarsname[$j] =~ /Plant Loop Heating Demand/ ||
                        $rpdvarsname[$j] =~ /Plant Loop Cooling Demand/ ||
                        $rpdvarsname[$j] =~ /Fan Electric Power/ ||
                        $rpdvarsname[$j] =~ /AirLoopHVAC Actual Outdoor Air Fraction/ ||
                        $rpdvarsname[$j] =~ /Plant Loop Unmet Demand/ ||
                        $rpdvarsname[$j] =~ /Chiller COP/ ||
                        $rpdvarsname[$j] =~ /Window Transmitted Solar/ ||
                        $rpdvarsname[$j] =~ /Total Shortwave Absorbed:All Glass Layers \[W\]/ ||
                        $rpdvarsname[$j] =~ /Status/ ||
                        $rpdvarsname[$j] =~ /Fraction/ ||
                        $rpdvarsname[$j] =~ /Lights Electric Power/ ||
                        $rpdvarsname[$j] =~ /Ratio/ )  #for these kind of variables, take average otherwise take sum

		{
			$temp_ = $sum_annual{'sum'}[$j]/12;
		}
		else
		{
			$temp_ = $sum_annual{'sum'}[$j];
		}
		if(
			$sum_annual{'maxval'}[$j] eq "" && $sum_annual{'maxday'}[$j] eq "" && $sum_annual{'maxhour'}[$j] eq "" &&
			$sum_annual{'maxminute'}[$j] eq "" && $sum_annual{'minval'}[$j] eq "" && $sum_annual{'minday'}[$j] eq "" &&
			$sum_annual{'minhour'}[$j] eq "" && $sum_annual{'minminute'}[$j] eq ""
		) # If the variable does not contain min, max, etc attributes then no need to print them
		{
			print OUTFILE "$rpdvarsid[$j],$temp_\n" ;
		}
		else
		{	
			print OUTFILE "$rpdvarsid[$j],$temp_," . 
			      "$sum_annual{'maxval'}[$j],$month_min,$sum_annual{'maxday'}[$j],$sum_annual{'maxhour'}[$j],$sum_annual{'maxminute'}[$j]," . 			      "$sum_annual{'minval'}[$j],$month_max,$sum_annual{'minday'}[$j],$sum_annual{'minhour'}[$j],$sum_annual{'minminute'}[$j]\n";
		}
	}
}
#############################################################################################################
print OUTFILE "End of Data\n";
print OUTFILE " Number of Records Written=       ";

close(OUTFILE);
$DesignDayLine =  $lineNumEndDDic + 1;
$numOfLine = `tail -n +$DesignDayLine sorted_final.eso | grep -iv "^[12345]," |  wc -l`;
$numOfLine = $numOfLine - 3;
`echo $numOfLine >> sorted_final.eso`;

#print $DesignDayLine;
#`sed 's/^4,44/4,31/' < sorted_final.eso > sorted_final.eso`;
