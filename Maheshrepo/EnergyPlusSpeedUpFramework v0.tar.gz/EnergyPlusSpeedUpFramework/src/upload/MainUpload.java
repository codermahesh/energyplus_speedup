package upload;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import ApplicationEnvironment.WorkingSettings;

public class MainUpload {
	static Random randomGenerator=null;
	public MainUpload(){
		randomGenerator=new Random();
	}
	public  void upload(String idf,String wthr){

		try{
			
			int k=randomGenerator.nextInt(999999);
			File dir = new File(WorkingSettings.dropboxfolder+"/Task"+k);
			dir.mkdir();
			
			

			ArrayList li=NodeListing.getNode();
			int len=li.size();
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("tasks");
			doc.appendChild(rootElement);
			Element node = doc.createElement("task");
			rootElement.appendChild(node);
			MachineNode mn=null;
			Element idChild = doc.createElement("id");
			idChild.appendChild(doc.createTextNode("task"+k));
			node.appendChild(idChild);
			Element idChild1 =null;
			for(int i=0;(i<len && i<12);i++){
				mn=(MachineNode)li.get(i);
				idChild= doc.createElement("node"+i);
				idChild.appendChild(doc.createTextNode(mn.getId()));
				node.appendChild(idChild);
				idChild=null;
			}
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(WorkingSettings.dropboxfolder+"/Task/task"+k+".xml"));
	 
			
	 
			transformer.transform(source, result);
			
			
			SplitInformation si=new SplitInformation(idf);
			si.split();
			
			
			File f=new File(idf);
			String folder=f.getParent();
			//sort by priority
			
			
			
			//copy the Files to Target
			int i=0;
			
			FileInputStream fis=null;
			FileOutputStream fos=null;
			byte[] buffer = new byte[1024]; 
			int length=0; 
			
			int j=1;
			for(;(i<len && i<12);i++){
				mn=(MachineNode)li.get(i);

				File aFile=new File(folder+"/"+j+".idf");
				File bFile=new File(WorkingSettings.dropboxfolder+"/Task"+k+"/"+mn.getId()+"_"+j+".idf");
				fis=new FileInputStream(aFile);
				fos=new FileOutputStream(bFile);
				while ((length = fis.read(buffer)) > 0){

					fos.write(buffer, 0, length);

				}
				fis.close();
				fos.close();
				fis=null;
				fos=null;
				j++;
			}
			
			Thread t=new Thread(new TaskCompleteChecker(WorkingSettings.dropboxfolder+"/Task"+k,j));
			t.start();
			//check For the Output

		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
