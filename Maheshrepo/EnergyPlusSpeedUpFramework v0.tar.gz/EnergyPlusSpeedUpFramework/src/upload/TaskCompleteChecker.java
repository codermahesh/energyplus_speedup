package upload;

import java.io.File;

import ApplicationEnvironment.WorkingSettings;

public class TaskCompleteChecker implements Runnable {

	String taskFolder="";
	int no=0;
	public TaskCompleteChecker(String taskFolder,int files){
		this.taskFolder=taskFolder;
		no=files;
	}
	@Override
	public void run() {
		try{
			File f=new File(taskFolder+"/output/");


			while(true){

				int noOfFiles=f.listFiles().length;
				if(noOfFiles==no){
					break;
				}

				Thread.sleep(1000);
			}
			
			//Call the Perl
			
			//Changes to Output
			
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
