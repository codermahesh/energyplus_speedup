package ApplicationEnvironment;


public enum Platform {
    WINDOWS,
    LINUX,
    MAC,
    UNDEFINED    
}
