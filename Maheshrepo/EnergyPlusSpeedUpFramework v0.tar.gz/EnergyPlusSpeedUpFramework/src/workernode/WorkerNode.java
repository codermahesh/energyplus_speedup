/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package workernode;

import ApplicationEnvironment.PlatformInformation;
import Task.TaskLauncher;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ybar
 */
public class WorkerNode 
{

    /**
     * @param args the command line arguments
     */
 /*   public static void main(String[] args) 
    {
                 
            ApplicationSettings settings = new ApplicationSettings();            
            settings.getApplicationSettings();
            
           System.out.println(settings.getProperty("simulationFile"));
           System.out.println(settings.getProperty("dropboxfolder"));
            
          
           
            Tray tray = new Tray("bulb.gif");
	    tray.RunInTray();
            
            /*Keep running till end 
	    	
           	
           	
	    
            TaskChecker();
            
    }
    */
 
    public static void TaskChecker()
    {
        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        final Runnable taskcheck = new Runnable() 
        {

            @Override
            public void run() 
            {
                boolean gotNewJob = false;
                
                System.out.println("Abhinay In Task Checker");
                if(gotNewJob)
                {
                        /*Launch*/
                    TaskLauncher tl = new TaskLauncher();
                    try 
                    {
                        tl.launch("C:\\EnergyPlusV8-0-0\\EP-Launch.exe", "", "");
                    } 
                    catch (IOException ex) 
                     {
                         JOptionPane.showMessageDialog(null,"Critical Error in Launch!");
                     }
                }
                
            }
        };
        
        scheduler.scheduleAtFixedRate(taskcheck,5, 10, TimeUnit.SECONDS);
    }
}
