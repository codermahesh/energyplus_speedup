package SystemMoniter;

public class MachineRanking 
{
		
	int rank;
	
	public int getRank()
	{
		
		return 0;
	}
	
	@SuppressWarnings("unused")
	private void setRank(int r)
	{
		this.rank = r;
	}
	
	
}
