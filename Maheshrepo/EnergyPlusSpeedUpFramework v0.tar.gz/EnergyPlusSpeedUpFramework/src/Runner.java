import javax.swing.JOptionPane;

import upload.NodeInsert;
import workernode.WorkerNode;

import ApplicationEnvironment.WorkingSettings;
import ApplicationGUI.ApplicationSettingsForm;
import ApplicationGUI.Tray;


public class Runner {

	/**
	 * @param args
	 */
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args)
	{
			/*Initialising Application*/
			
			/*Check for single instance*/
			if(!SingleInstanceProvider.lockApplication())
			{
				JOptionPane.showMessageDialog(null,"Application is Already Running !");
				System.exit(0);
			}
			
			/*Read Settings*/
			if(!WorkingSettings.LoadAppProperties())
			{
					ApplicationSettingsForm form =  new ApplicationSettingsForm();
					form.show();
			}
			
			/*Keep Application live in Tray*/
			Tray tray = new Tray("Resources/iiit.gif");
			WorkerNode.TaskChecker();
			try{
			NodeInsert ni=new NodeInsert("Abhinay");
			}catch(Exception e){
				e.printStackTrace();
			}
			tray.RunInTray();

			
	}

}
