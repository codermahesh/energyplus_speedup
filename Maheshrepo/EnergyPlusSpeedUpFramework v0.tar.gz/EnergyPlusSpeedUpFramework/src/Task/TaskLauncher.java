/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Task;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ybar
 */
public class TaskLauncher 
{
        public TaskLauncher()
        {
        }
        
        public void  launch(String Input_idf,String Input_weather,String outputFolder) throws IOException
        {
            String cmdarg[]={"","",""};
            cmdarg[0]=Input_idf;
            cmdarg[1]=Input_weather;
            cmdarg[2]=outputFolder;
            System.out.println(cmdarg[1]);
            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec(cmdarg);

        }
        
        
        public static void main(String[] args)
        {
            TaskLauncher tl = new TaskLauncher();
            try 
            {
                tl.launch("C:\\EnergyPlusV8-0-0\\EP-Launch.exe", "", "");
            } 
            catch (IOException ex) 
            {
                Logger.getLogger(TaskLauncher.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
}
