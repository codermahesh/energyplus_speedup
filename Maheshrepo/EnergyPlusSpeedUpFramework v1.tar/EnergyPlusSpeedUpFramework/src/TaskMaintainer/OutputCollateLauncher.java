package TaskMaintainer;

import java.io.IOException;

public class OutputCollateLauncher 
{
	
	 public static void  launchCollate(String esoFolder,String outputFolder) throws IOException
     {
         String cmdarg[]={"","",""};

         
         Runtime runtime = Runtime.getRuntime();
         Process process = runtime.exec(cmdarg);

     }

}
